import streamlit as st
from llm_qa_system import CompanyIntelligenceAgent
import pandas as pd

# Page config
st.set_page_config(
    page_title="Toyota Intelligence Dashboard",
    page_icon="🚗",
    layout="wide"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1.5rem;
        border-radius: 15px;
        color: white;
        text-align: center;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    .metric-card-risk {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        padding: 1.5rem;
        border-radius: 15px;
        color: white;
        text-align: center;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    .metric-card-esg {
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        padding: 1.5rem;
        border-radius: 15px;
        color: white;
        text-align: center;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    .metric-card-business {
        background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
        padding: 1.5rem;
        border-radius: 15px;
        color: white;
        text-align: center;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    .metric-value {
        font-size: 2.5rem;
        font-weight: 800;
        margin-bottom: 0.5rem;
    }
    .metric-label {
        font-size: 1rem;
        opacity: 0.9;
    }
    .section-header {
        font-size: 1.5rem;
        font-weight: 700;
        color: #2D3748;
        margin: 1.5rem 0 1rem 0;
        padding-bottom: 0.5rem;
        border-bottom: 3px solid #4FD1C7;
    }
    .company-summary {
        background-color: #F7FAFC;
        padding: 1.5rem;
        border-radius: 10px;
        border-left: 5px solid #4299E1;
        margin: 1rem 0;
        font-size: 1.1rem;
        line-height: 1.6;
    }
</style>
""", unsafe_allow_html=True)

# Header
st.title("🚗 Toyota Company Intelligence Dashboard")
st.subheader("AI-powered analysis of Toyota's corporate documents")
st.markdown("---")

# ==================== COMPANY SUMMARY ====================
st.markdown("### 🏢 Company Overview")
st.markdown("""
<div class="company-summary">
    <strong>Toyota Motor Corporation</strong> is a global automotive leader operating in <strong>170+ countries</strong> 
    with manufacturing plants in <strong>28 countries</strong>. The company's core business segments are 
    <strong>Automotive</strong> (vehicle manufacturing) and <strong>Financial Services</strong> (financing & leasing), 
    with strategic focus on <strong>hybrid vehicles</strong> and <strong>sustainable mobility solutions</strong>.
</div>
""", unsafe_allow_html=True)

# ==================== ENHANCED KPI METRICS SECTION ====================
st.markdown('<div class="section-header">📊 Document & Analysis Metrics</div>', unsafe_allow_html=True)

# Row 1: Document Stats
col1, col2, col3 = st.columns(3)
with col1:
    st.markdown("""
    <div class="metric-card">
        <div class="metric-value">292</div>
        <div class="metric-label">Document Chunks</div>
        <div style="font-size: 0.85rem; margin-top: 0.5rem;">Processed from 3 source files</div>
    </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown("""
    <div class="metric-card">
        <div class="metric-value">3</div>
        <div class="metric-label">Source Files</div>
        <div style="font-size: 0.85rem; margin-top: 0.5rem;">10-K • ESG Report • News</div>
    </div>
    """, unsafe_allow_html=True)

with col3:
    st.markdown("""
    <div class="metric-card">
        <div class="metric-value">5+</div>
        <div class="metric-label">ESG Targets</div>
        <div style="font-size: 0.85rem; margin-top: 0.5rem;">Carbon, Diversity, Circular Economy</div>
    </div>
    """, unsafe_allow_html=True)

# Row 2: Risk Analysis
st.markdown('<div class="section-header">⚠️ Risk Analysis</div>', unsafe_allow_html=True)
col1, col2, col3, col4 = st.columns(4)

with col1:
    st.markdown("""
    <div class="metric-card-risk">
        <div class="metric-value">112</div>
        <div class="metric-label">Risk Mentions</div>
        <div style="font-size: 0.85rem; margin-top: 0.5rem;">Across all documents</div>
    </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown("""
    <div class="metric-card-risk">
        <div class="metric-value">4</div>
        <div class="metric-label">Top Risk Areas</div>
        <div style="font-size: 0.85rem; margin-top: 0.5rem;">Supply chain • Materials • Regulations • Competition</div>
    </div>
    """, unsafe_allow_html=True)

with col3:
    st.markdown("""
    <div class="metric-card-risk">
        <div class="metric-value">28</div>
        <div class="metric-label">Countries</div>
        <div style="font-size: 0.85rem; margin-top: 0.5rem">Manufacturing Plants</div>
    </div>
    """, unsafe_allow_html=True)

with col4:
    st.markdown("""
    <div class="metric-card-risk">
        <div class="metric-value">170+</div>
        <div class="metric-label">Markets</div>
        <div style="font-size: 0.85rem; margin-top: 0.5rem">Global Operations Footprint</div>
    </div>
    """, unsafe_allow_html=True)

# Row 3: ESG Analysis
st.markdown('<div class="section-header">🌱 ESG & Sustainability</div>', unsafe_allow_html=True)
col1, col2, col3 = st.columns(3)

with col1:
    st.markdown("""
    <div class="metric-card-esg">
        <div class="metric-value">209</div>
        <div class="metric-label">ESG Mentions</div>
        <div style="font-size: 0.85rem; margin-top: 0.5rem;">Environmental, Social, Governance</div>
    </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown("""
    <div class="metric-card-esg">
        <div class="metric-value">2050</div>
        <div class="metric-label">Carbon Neutrality</div>
        <div style="font-size: 0.85rem; margin-top: 0.5rem;">Target Year</div>
    </div>
    """, unsafe_allow_html=True)

with col3:
    st.markdown("""
    <div class="metric-card-esg">
        <div class="metric-value">90%</div>
        <div class="metric-label">CO₂ Reduction</div>
        <div style="font-size: 0.85rem; margin-top: 0.5rem;">Vehicle lifecycle vs. 2010</div>
    </div>
    """, unsafe_allow_html=True)

# Row 4: Business Segments
st.markdown('<div class="section-header">🏢 Business Segments</div>', unsafe_allow_html=True)
col1, col2, col3 = st.columns(3)

with col1:
    st.markdown("""
    <div class="metric-card-business">
        <div class="metric-value">Automotive</div>
        <div class="metric-label">Core Business</div>
        <div style="font-size: 0.85rem; margin-top: 0.5rem;">Vehicle Manufacturing & Sales</div>
    </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown("""
    <div class="metric-card-business">
        <div class="metric-value">Financial</div>
        <div class="metric-label">Services</div>
        <div style="font-size: 0.85rem; margin-top: 0.5rem;">Financing & Leasing</div>
    </div>
    """, unsafe_allow_html=True)

with col3:
    st.markdown("""
    <div class="metric-card-business">
        <div class="metric-value">Hybrid</div>
        <div class="metric-label">Technology Focus</div>
        <div style="font-size: 0.85rem; margin-top: 0.5rem;">Electrified Vehicles Leadership</div>
    </div>
    """, unsafe_allow_html=True)

st.markdown("---")

# ==================== Q&A SECTION ====================
st.markdown("### 💬 Ask Questions About Toyota")

# Initialize agent
@st.cache_resource
def load_agent():
    return CompanyIntelligenceAgent("data/toyota_chunks.csv")

agent = load_agent()

# Question Input
question = st.text_input(
    "Enter your question about Toyota's business, risks, ESG goals, or operations:",
    placeholder="Example: What are Toyota's main risk factors?",
    label_visibility="collapsed"
)

col1, col2 = st.columns([3, 1])
with col2:
    ask_button = st.button("🔍 Get Answer", type="primary", use_container_width=True)

# Process question
if ask_button or question:
    if not question.strip():
        st.warning("Please enter a question.")
    else:
        with st.spinner("🔍 Searching through 292 document chunks..."):
            answer, sources = agent.ask_question(question, top_k=3)
        
        # Display retrieved evidence
        st.markdown("### 📄 Retrieved Evidence")
        st.info(f"**Top {len(sources)} relevant chunks found:** {', '.join(sources)}")
        
        # Display answer
        st.markdown("### 🤖 LLM Answer with Citations")
        st.success(answer)
        
        # Source details expander
        with st.expander("📋 View detailed source information"):
            for source in sources:
                st.markdown(f"**{source}**")
                st.caption("From Toyota corporate documents")

# Footer
st.markdown("---")
st.markdown("""
<div style="text-align: center; color: #6B7280; font-size: 0.9rem;">
    <strong>DSB431 Case Study 2</strong> • Company Intelligence Agent • Powered by OpenAI GPT-3.5 Turbo<br>
    <span style="font-size: 0.8rem;">Retrieval-Augmented Generation (RAG) with TF-IDF • Enhanced KPI Dashboard</span>
</div>
""", unsafe_allow_html=True)
