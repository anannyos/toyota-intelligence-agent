import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def get_openai_answer(question, context_chunks):
    # Format context
    context_text = "\n".join([f"[{chunk_id}]: {chunk_text}" 
                             for chunk_id, chunk_text in context_chunks])
    
    prompt = f"""Answer using ONLY this context. Cite chunk IDs like [chunk_1].

Context:
{context_text}

Question: {question}

Answer:"""
    
    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.1
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"Error: {str(e)[:100]}"
