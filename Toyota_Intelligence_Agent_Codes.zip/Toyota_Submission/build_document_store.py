import pandas as pd
import os
from pypdf import PdfReader
import re

def extract_text_from_pdf(pdf_path):
    """Extract text from a PDF file"""
    text = ""
    try:
        reader = PdfReader(pdf_path)
        for page in reader.pages:
            text += page.extract_text() + "\n"
        return text
    except Exception as e:
        print(f"Error reading {pdf_path}: {e}")
        return ""

def clean_text(text):
    """Clean extracted text by removing extra whitespace and page numbers"""
    # Remove excessive whitespace
    text = re.sub(r'\n+', '\n', text)
    text = re.sub(r' +', ' ', text)
    
    # Remove common page number patterns
    text = re.sub(r'\n\d+\n', '\n', text)
    
    return text.strip()

def chunk_text(text, chunk_size=500):
    """Split text into chunks of approximately chunk_size words"""
    words = text.split()
    chunks = []
    
    for i in range(0, len(words), chunk_size):
        chunk = ' '.join(words[i:i + chunk_size])
        chunks.append(chunk)
    
    return chunks

def build_document_store(company_name="toyota"):
    """Main function to build the document store"""
    base_path = f"data/{company_name}"
    
    # Define document sources
    documents = [
        {"file": "annual_report_excerpt.pdf", "type": "annual_report"},
        {"file": "esg_excerpt.pdf", "type": "esg_report"},
        {"file": "external_summary.txt", "type": "external_summary"}
    ]
    
    all_chunks = []
    chunk_id = 0
    
    for doc in documents:
        file_path = os.path.join(base_path, doc["file"])
        
        if doc["file"].endswith('.pdf'):
            text = extract_text_from_pdf(file_path)
        else:  # txt file
            with open(file_path, 'r', encoding='utf-8') as f:
                text = f.read()
        
        if text:
            cleaned_text = clean_text(text)
            chunks = chunk_text(cleaned_text)
            
            for i, chunk in enumerate(chunks):
                all_chunks.append({
                    "chunk_id": f"{doc['type']}_{chunk_id}",
                    "company": company_name,
                    "source_file": doc["file"],
                    "chunk_text": chunk,
                    "chunk_number": i,
                    "document_type": doc["type"]
                })
                chunk_id += 1
    
    # Create DataFrame
    df = pd.DataFrame(all_chunks)
    
    # Save to CSV
    output_path = f"data/{company_name}_chunks.csv"
    df.to_csv(output_path, index=False)
    
    print(f"✅ Document store created successfully!")
    print(f"📊 Total chunks: {len(df)}")
    print(f"📁 Saved to: {output_path}")
    
    # Show chunk distribution
    print("\n📈 Chunk distribution by document type:")
    print(df['document_type'].value_counts())
    
    return df

if __name__ == "__main__":
    # Build the document store
    document_df = build_document_store("toyota")
    
    # Display first few chunks
    print("\n🔍 Sample chunks:")
    print(document_df[['chunk_id', 'document_type', 'chunk_text']].head(3))