import pandas as pd
df = pd.read_csv("data/toyota_chunks.csv")
print("KPI REPORT:")
print(f"1. Documents: {len(df)} chunks")
print(f"2. Sources: {df['source_file'].nunique()} files")
print(f"3. Risks mentioned: {sum('risk' in t.lower() for t in df['chunk_text'])}")
print(f"4. ESG mentioned: {sum('esg' in t.lower() or 'environment' in t.lower() for t in df['chunk_text'])}")
print("5. Business: Automotive, Financial, Global")
print("DONE")
