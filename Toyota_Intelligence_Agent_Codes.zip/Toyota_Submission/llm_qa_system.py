import os
from dotenv import load_dotenv
from retrieval_system import DocumentRetriever
from openai_agent import get_openai_answer  # Use OpenAI instead

load_dotenv()

class CompanyIntelligenceAgent:
    def __init__(self, chunks_csv_path):
        self.retriever = DocumentRetriever(chunks_csv_path)
        print("✅ Company Intelligence Agent initialized with OpenAI GPT-3.5 Turbo")
    
    def _build_prompt(self, question, relevant_chunks):
        context_text = ""
        for chunk in relevant_chunks:
            context_text += f"[CHUNK ID: {chunk['chunk_id']}]: {chunk['chunk_text']}\n\n"
        
        prompt = f"""Answer using ONLY this context:
{context_text}
Question: {question}
Rules: Cite CHUNK IDs. List sources."""
        return prompt
    
    def ask_question(self, question, top_k=3):
        # Retrieve relevant chunks
        relevant_chunks = self.retriever.search(question, top_k=top_k)
        
        if not relevant_chunks:
            return "No relevant chunks found.", []
        
        # Format for OpenAI
        context_chunks = [(chunk['chunk_id'], chunk['chunk_text']) 
                         for chunk in relevant_chunks]
        
        # Get answer from OpenAI
        answer = get_openai_answer(question, context_chunks)
        
        # Extract source IDs
        source_ids = [chunk['chunk_id'] for chunk in relevant_chunks]
        
        return answer, source_ids

# Test
if __name__ == "__main__":
    agent = CompanyIntelligenceAgent("data/toyota_chunks.csv")
    test_q = "What does Toyota do?"
    answer, sources = agent.ask_question(test_q, top_k=2)
    print(f"Q: {test_q}")
    print(f"A: {answer}")
    print(f"Sources: {sources}")
