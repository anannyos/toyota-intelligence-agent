import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import re

class DocumentRetriever:
    def __init__(self, chunks_csv_path):
        """Initialize the retriever with document chunks"""
        self.df = pd.read_csv(chunks_csv_path)
        self.vectorizer = TfidfVectorizer(stop_words='english', max_features=1000)
        self.tfidf_matrix = None
        self._fit_tfidf()
    
    def _fit_tfidf(self):
        """Fit TF-IDF vectorizer on all chunks"""
        texts = self.df['chunk_text'].fillna('').tolist()
        self.tfidf_matrix = self.vectorizer.fit_transform(texts)
        print(f"TF-IDF model trained on {len(texts)} documents")
    
    def search(self, query, top_k=5):
        """Search for most relevant chunks"""
        # Convert query to TF-IDF vector
        query_vec = self.vectorizer.transform([query])
        
        # Calculate cosine similarity
        similarities = cosine_similarity(query_vec, self.tfidf_matrix).flatten()
        
        # Get top-k most similar chunks
        top_indices = similarities.argsort()[-top_k:][::-1]
        
        results = []
        for idx in top_indices:
            if similarities[idx] > 0:  # Only include relevant results
                chunk_data = self.df.iloc[idx].to_dict()
                chunk_data['similarity_score'] = float(similarities[idx])
                results.append(chunk_data)
        
        return results
    
    def print_results(self, results, query):
        """Print search results in a readable format"""
        print(f"Query: '{query}'")
        print(f"Found {len(results)} relevant chunks:")
        print("-" * 80)
        
        for i, result in enumerate(results, 1):
            print(f"{i}. Score: {result['similarity_score']:.3f}")
            print(f"   Source: {result['source_file']} (Chunk {result['chunk_number']})")
            print(f"   Type: {result['document_type']}")
            # Show preview of text (first 150 characters)
            preview = result['chunk_text'][:150] + "..." if len(result['chunk_text']) > 150 else result['chunk_text']
            print(f"   Text: {preview}")
            print()

# Test the retrieval system
if __name__ == "__main__":
    # Initialize retriever
    retriever = DocumentRetriever("data/toyota_chunks.csv")
    
    # Test queries
    test_queries = [
        "What does Toyota do?",
        "What are Toyota's main business segments?",
        "What are Toyota's environmental goals?",
        "What risks does Toyota face?"
    ]
    
    for query in test_queries:
        results = retriever.search(query, top_k=3)
        retriever.print_results(results, query)