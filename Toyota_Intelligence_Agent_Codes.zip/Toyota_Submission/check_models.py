import google.generativeai as genai
import os
from dotenv import load_dotenv

load_dotenv()

# Configure with your API key
api_key = os.getenv("GEMINI_API_KEY")
print(f"API Key starts with: {api_key[:20]}")
genai.configure(api_key=api_key)

try:
    # List all available models
    print("\n=== Listing available models ===")
    models = genai.list_models()
    
    for i, model in enumerate(models):
        print(f"\nModel {i+1}:")
        print(f"  Name: {model.name}")
        print(f"  Display Name: {model.display_name}")
        print(f"  Description: {model.description}")
        print(f"  Supported methods: {model.supported_generation_methods}")
        
except Exception as e:
    print(f"\nError listing models: {type(e).__name__}: {e}")
    
    # Try a direct test with common model names
    print("\n=== Testing common model names ===")
    common_models = [
        "gemini-1.5-pro",
        "gemini-1.5-flash", 
        "gemini-pro",
        "gemini-1.0-pro",
        "models/gemini-1.5-pro",
        "models/gemini-pro"
    ]
    
    for model_name in common_models:
        try:
            model = genai.GenerativeModel(model_name)
            response = model.generate_content("Hello")
            print(f"✓ {model_name}: WORKING - {response.text[:50]}...")
        except Exception as e:
            print(f"✗ {model_name}: {type(e).__name__}")
